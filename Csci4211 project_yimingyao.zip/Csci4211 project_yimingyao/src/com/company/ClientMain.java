package com.company;

public class ClientMain {
    static Client client;
    public static void main(String[] args) {
        client = new Client();
    }
}
